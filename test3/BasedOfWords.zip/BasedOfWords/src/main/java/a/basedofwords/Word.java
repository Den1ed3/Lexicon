
public class Word {

    private String str;
    private int integer;

    public Word() {
    }

    public Word(String str, int integer) {
        this.str = str;
        this.integer = integer;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public int getInteger() {
        return integer;
    }

    public void setInteger(int integer) {
        this.integer = integer;
    }

}
